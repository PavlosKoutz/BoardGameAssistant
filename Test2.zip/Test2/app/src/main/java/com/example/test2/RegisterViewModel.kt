import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

import androidx.lifecycle.ViewModel
import com.example.test2.ItemWithCounters
import com.example.test2.Register

class RegisterViewModel : ViewModel() {


    val registerList = mutableStateListOf<Register>()
    val shuffledList = mutableStateListOf<Register>()
    val properties1=mutableStateListOf<ItemWithCounters>()
    val properties2=mutableStateListOf<ItemWithCounters>()
    val properties3=mutableStateListOf<ItemWithCounters>()
    val properties4=mutableStateListOf<ItemWithCounters>()
    val properties5=mutableStateListOf<ItemWithCounters>()
    val properties6=mutableStateListOf<ItemWithCounters>()
    val properties7=mutableStateListOf<ItemWithCounters>()
    val properties8=mutableStateListOf<ItemWithCounters>()




    fun addRegister(name: String, money: Int = 0, houses: Int = 0, hotel: Int = 0) {
        if (name.isNotBlank() && registerList.size < 8) {
            val newPlayer = Register(
                Name = name,
                MoneyValue = money,
                housesValue = listOf(0),  // or the number of properties you want to track
                hotelValue = listOf(0),
            )

            registerList.add(newPlayer)
            shuffledList.clear()
            shuffledList.addAll(registerList.shuffled())
        }
    }



    fun removeRegister(name: String) {
        registerList.removeAll { it.Name == name }
        shuffledList.removeAll { it.Name == name }
    }

    fun shuffleNames() {
        shuffledList.clear()
        shuffledList.addAll(registerList.shuffled())
    }


    fun updateMoney(name: String, newMoney: Int) {
        val register = registerList.find { it.Name == name }
        register?.Money?.value = newMoney
    }


}

